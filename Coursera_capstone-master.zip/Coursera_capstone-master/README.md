# Coursera_capstone
This repository contains the applied datastone capstone project for IBM through Coursera.
It consist of only week 4 and week 5 assignments.

Week 4 assignment tasks :
1. Describing the problem statement : Giving background insights and explaining the problem statement thoroughly. Also explaining the scope and success rate of the problem.
2. Data requirements and collection sources : What data is required accoring to the problem statement and explaining how data will get you to the solution.

Week 5 assignment tasks: 
1. Preparation of code : If problem statement and data requirements are understood very well, this step is easy. So understading week 4 task's is very important. Week 3 congnitive class lab assignment notebooks generally do help a lot in writing the code for the final capstone project.
2. Praparation of report: The report is initially written as a word document and then converted into a pdf format during submission. The report consists of 5 parts : 
    a. Introduction section (basically the problem statement. So week 4 part 1 will help.)
    b. Methodolgy section : descibing your approch on handling data and what methods your might use while approching towards the target.
    c. Result section : Describing your results and also any output supporting the results.
    d. Discussion section : This is an important section as it shows all the infernces and analysis that you did on your project.
    e. Conclusion section: Concluding statement of the project and also its future scope.

3. Presentation: Similar to project report but less text content.
